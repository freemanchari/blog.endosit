jQuery(document).ready(function() {
	 jQuery('#tabvanilla > ul').tabs({ fx: [{opacity:'toggle', duration:'normal'},                       							  																  {opacity:'toggle', duration:'fast'}] });
});